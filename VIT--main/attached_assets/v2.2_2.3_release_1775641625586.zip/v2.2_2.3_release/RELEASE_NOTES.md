# VIT Sports Intelligence — v2.2.0 + v2.3.0 Release

## Files in This Release

```
v2.2_2.3_release/
├── app/api/routes/
│   └── admin.py                  ← v2.2 + v2.3 backend endpoints
├── frontend/src/
│   ├── api.js                    ← All new API calls
│   ├── AdminPanel.jsx            ← v2.2 redesigned admin panel
│   ├── AccumulatorPanel.jsx      ← v2.3 new accumulator generator
│   └── App.jsx                   ← Added Accumulator tab
└── RELEASE_NOTES.md
```

## v2.2.0 — Admin Control Panel

### New Backend Endpoints
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/admin/models/status` | GET | Per-model status, weight, error |
| `/admin/models/reload` | POST | Reload all 12 models |
| `/admin/data-sources/status` | GET | Football API + Odds API health |
| `/admin/matches/manual` | POST | Add fixture + run prediction |
| `/admin/upload/csv` | POST | Bulk upload fixtures |

### Admin Panel Sections
1. **Model Status** — table showing each of 12 models (Ready/Failed), weight, error message, with Reload All button
2. **Data Source Health** — Football-Data.org and Odds API live/down/no-key badges
3. **Manual Match Entry** — form to add a single fixture with custom odds
4. **CSV Bulk Upload** — drag-drop CSV → batch predictions in a table
5. **Auto-Fetch & Predict** — existing stream with model count column added

## v2.3.0 — Accumulator Generator

### New Backend Endpoints
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/admin/accumulator/candidates` | GET | Top picks filtered by edge/confidence |
| `/admin/accumulator/generate` | POST | Build top-N accumulators from candidates |
| `/admin/accumulator/send` | POST | Push accumulator to Telegram |

### Accumulator Panel (3-Step Flow)
1. **Step 1 — Fetch Candidates** — runs predictions on upcoming fixtures, returns matches with positive edge. Filter by min confidence and min edge.
2. **Step 2 — Build Accumulators** — select/deselect individual candidates, choose 2–8 legs, generates all combinations ranked by adjusted edge (with same-league correlation penalty).
3. **Step 3 — Top Accumulators** — cards showing combined odds, edge, per-leg breakdown, and "Send to Telegram" button.

### Accumulator Edge Formula
```
combined_edge = combined_model_prob - (1 / combined_market_odds)
penalty       = same_league_pairs × 0.015
adjusted_edge = combined_edge - penalty
```

## How to Deploy on Replit

Paste this into Replit Agent:

```
I have new files in v2.2_2.3_release/. Please:
1. Replace app/api/routes/admin.py with v2.2_2.3_release/app/api/routes/admin.py
2. Replace frontend/src/api.js with v2.2_2.3_release/frontend/src/api.js
3. Replace frontend/src/AdminPanel.jsx with v2.2_2.3_release/frontend/src/AdminPanel.jsx
4. ADD frontend/src/AccumulatorPanel.jsx from v2.2_2.3_release/frontend/src/AccumulatorPanel.jsx
5. Replace frontend/src/App.jsx with v2.2_2.3_release/frontend/src/App.jsx
6. Do not change any other files.
7. Run: cd frontend && npm run build
8. Restart the app.
```

## Next: v2.4.0 — Training Pipeline
- Trigger model retraining from UI
- Live training progress via WebSocket
- Compare old vs new model accuracy
- Promote or rollback with one click
