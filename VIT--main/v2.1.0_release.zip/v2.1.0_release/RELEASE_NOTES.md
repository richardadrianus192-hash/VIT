# VIT Sports Intelligence — v2.1.0 Release

## What's Fixed

| Gap | Root Cause | Fix |
|-----|-----------|-----|
| Prediction always "NONE" | Models failing → flat 33/33/33 → no edge | Market-implied fallback in orchestrator |
| All matches showing 36.3% | Default odds 2.75 used (1/2.75 = 36.3%) | Real odds validated + fallback chain |
| Edge always 0.00% | Flat probs can't beat vig-free market | Proper blend of model + market probs |
| Stake always 0.0% | No positive edge → Kelly = 0 | Fixed upstream |
| Confidence always 50% | Default when no models respond | Model agreement scoring (0.60–0.90) |
| Models always 0/0 | BetAlert had no models_used field | Added to BetAlert dataclass + alert |

## Files in This Release

```
v2.1.0_release/
├── services/ml_service/models/
│   └── model_orchestrator.py     ← Core fix: market fallback + confidence
├── app/
│   ├── services/
│   │   ├── alerts.py             ← New Telegram format with all fields
│   │   └── market_utils.py       ← Odds validation + estimation fallback
│   └── api/routes/
│       └── predict.py            ← Wires everything together
└── RELEASE_NOTES.md              ← This file
```

## How to Deploy on Replit

### Option A — Manual (no agent credits)
Copy each file into your project, replacing the existing file at the same path.

### Option B — Replit Agent (minimal prompt)
Paste this into the Replit Agent chat:

```
I have 4 replacement files in my project root under v2.1.0_release/.
Please:
1. Replace services/ml_service/models/model_orchestrator.py with v2.1.0_release/services/ml_service/models/model_orchestrator.py
2. Replace app/services/alerts.py with v2.1.0_release/app/services/alerts.py
3. Replace app/services/market_utils.py with v2.1.0_release/app/services/market_utils.py
4. Replace app/api/routes/predict.py with v2.1.0_release/app/api/routes/predict.py
5. Do not change any other files.
6. Restart the app after replacing.
```

## What to Expect After Deploy

**Liverpool (odds 1.40/4.50/7.00):**
```
📈 Probabilities:
  Home: 68.5%  Draw: 21.2%  Away: 10.3%
💰 Edge: +4.2% 🔥🔥
💵 Stake: 3.2% of bankroll
🤖 Models: 0/12 models loading  ← shows actual count
```

**Everton (odds 2.00/3.20/3.80):**
```
📈 Probabilities:
  Home: 47.8%  Draw: 32.1%  Away: 20.1%
💰 Edge: -0.8%
💵 Stake: 0.0% — skip this match
```

## Next Steps (v2.2.0)
- Admin panel model reload controls
- Manual match entry form
- CSV upload for fixtures
- Model status dashboard
